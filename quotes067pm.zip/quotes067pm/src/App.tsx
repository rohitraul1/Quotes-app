
import './App.css';
import Login from './component/pages/login';
import AppBar from './component/common/appBar';
import Quotes from './component/pages/quotes';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import Home from 'component/pages/home';
import Authors from 'component/pages/authors';
import MyQuotes from 'component/pages/myQuotes';
import SignUp from 'component/pages/signUp';
import PrivateRoutes from './component/common/PrivateRoutes'

function App() {
  return (
    <div className="App" >
      <Router>
        <AppBar />
        <Routes>
          <Route element={<PrivateRoutes />}>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/authors" element={<Authors />} />
            <Route path="/myQuotes" element={<MyQuotes />} />
          </Route>
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/signUp" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
