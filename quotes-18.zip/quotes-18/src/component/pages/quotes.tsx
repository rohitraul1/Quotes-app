import React, { useEffect, useState } from 'react';
import { Card, Typography, Box, Button, Dialog, DialogTitle, TextField, IconButton, styled, Paper, InputBase, MenuItem, Stack, ButtonGroup, DialogContent, Chip } from '@mui/material';
import axios from "axios";
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import Grid from '@mui/system/Grid';
import Badge, { BadgeProps } from '@mui/material/Badge';
import SaveIcon from '@mui/icons-material/Save';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';

import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

const defaultProps = {
  bgcolor: 'background.paper',
  m: 1,
  border: 1,
  boxShadow: 2,
  borderColor: '#cfc100',
};

function Quotes() {

  const [open, setOpen] = React.useState(false);
  const [openViewCount, setOpenViewCount] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };  

  const quoteUrl = axios.create({
    baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
  });



  const [postsquote, setPostsquote] = useState<any[]>([]);
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const [tags, setTags] = useState('');
  const token = sessionStorage.getItem('token');
  const [posts, setPosts] = useState<any[]>([]);
  const userId = sessionStorage.getItem('userId');

  const [searchItem, setSearchItem] = useState('')
  const [dropdownOption, setDropdownOption] = useState('')
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [value, setValue] = React.useState('1');
  const [quoteId, setQuoteId] = React.useState();

  const[likequoteusers, setLikequoteusers] = useState<any[]>([]);
  const[dislikequoteusers, setDislikequoteusers] = useState<any[]>([]);

  const quotelikebyuserUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}/like/users`
  });

  const quotedislikebyuserUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}/dislike/users`
  });

  const handleLikequoteusers = async () => {
    try {
      let response = await quotelikebyuserUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setLikequoteusers(response.data);
    } catch (error) {
    }
    setOpenViewCount(true);
  };

  const handledisLikequoteusers = async () => {
    console.log("quoteId quote page",quoteId)
    try {
      let response = await quotedislikebyuserUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setDislikequoteusers(response.data);
    } catch (error) {
    }
    console.log("posts quote page",likequoteusers)
    setOpenViewCount(true);
  };

  const handlViewCountClose = () => {
    setOpenViewCount(false);
  };

  const handleInputChange = () => {
    filterData(searchItem);
  }

  const filterData = (searchItem: string) => {
    if (dropdownOption.toLowerCase() == "author") {
      getFilteredDataByAuthor(searchItem);
    } else if (dropdownOption.toLowerCase() == "quote") {
      getFilteredDataByQuote(searchItem)
    } else {
      getFilteredDataByTag(searchItem)
    }
  };

  const getFilteredDataByAuthor = (searchItem: string) => {
    const authorData = posts.filter((item) => item.author.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(authorData);
  };

  const getFilteredDataByQuote = (searchItem: string) => {
    const quoteData = posts.filter((item) => item.quote.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(quoteData);
  };

  const getFilteredDataByTag = (searchItem: string) => {
    const tagData = posts.filter((item) => item.tags.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(tagData);
  };

  // Sumit qoutes
  const handleSubmitQutoes = (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    addPostsqutoes(quote, author, tags);
  };

  // POST with Axios Qutoes
  const addPostsqutoes = async (quote: string, author: string, tags: string) => {

    try {
      let response = await quoteUrl.post('', {
        "quote": quote,
        "author": author,
        "tags": tags
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPostsquote([response.data, ...postsquote]);
      setQuote('');
      setAuthor('');
      setTags('');
    } catch (error) {
      console.log(error);
    }
  };

  const slectTab = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  useEffect(() => {
    const fetchPost = async () => {
      try {
        let response = await quoteUrl.get('', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        setPosts(response.data);
      } catch (error) {
      }
    };
    fetchPost();
  }, []);

  const StyledBadge = styled(Badge)<BadgeProps>(({ theme }) => ({
    '& .MuiBadge-badge': {
      right: -3,
      top: 13,
      border: `2px solid ${theme.palette.background.paper}`,
      padding: '0 4px',
    },
  }));

  const dropdown = [
    {
      value: 'author',
      label: 'Author',
    },
    {
      value: 'quote',
      label: 'Quote',
    },
    {
      value: 'tags',
      label: 'Tags',
    }
  ];

  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
      padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));

  return (

    <><Box sx={{ minWidth: 275, mx: 8, }}>
      <Typography
        component="h1"
        variant="h4"
        sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)', my: 2, ml: 1, textAlign: 'left' }}
      >Quotes</Typography>
      <Card elevation={3} sx={{ my: 2, px: 12, py: 3 }}>
        <Grid container>
          <Grid size={8}>
            <Stack spacing={2} direction="row">
              <TextField
                select
                label="Select"
                defaultValue=""
                onChange={(e) => setDropdownOption(e.target.value)}
                sx={{ width: 200 }}
              >
                {dropdown.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <Paper
                component="form"
                sx={{ mt: 3, ml: 12, p: '2px 4px', display: 'flex', alignItems: 'center', width: 400, height: 52 }}
              >
                <InputBase
                  type="text"
                  sx={{ ml: 1, flex: 1 }}
                  placeholder="Search"
                  inputProps={{ 'aria-label': 'search' }}
                  onChange={(e) => setSearchItem(e.target.value)}
                />
                <IconButton type="button" sx={{ p: '10px', backgroundColor: '#b1ac16','&:hover': {backgroundColor: '#736f09'}, color: '#ffffff' }} aria-label="search" onClick={handleInputChange}>
                  <SearchIcon />
                </IconButton>
              </Paper>
            </Stack>
          </Grid>
          <Grid size={4}>
            {token ? <Button variant="contained" onClick={handleClickOpen} sx={{ mt: 1, backgroundColor: '#b1ac16',width:'auto', ml:'auto' }}>
              <AddIcon /> Add Quote
            </Button> : null}
          </Grid></Grid>
        {filteredData.length >= 1 ?
          <><Box>
            {filteredData.length >= 1 ?
              <Box>{filteredData.map((post) => {
                return (
                  <>
                    <Box {...defaultProps} sx={{ my: 3, p: 0, mx:0 }} borderRadius={4} key={post.id}>
                      <Grid container spacing={2}>
                        <Grid size={11} sx={{ p: 3 }}>
                          <Typography variant="subtitle1" align='left'>
                            {post.quote}
                          </Typography>
                        </Grid>
                        {userId == post.user.id ?
                          <Grid size={1} sx={{ width: 42, height: 27, backgroundColor: "#90b021", mt: 0.6, borderRadius: 2 }}>
                            <PersonAddIcon sx={{ color: "#ffffff" }} />
                          </Grid> : null}
                        <Grid size={3}>
                        <ButtonGroup variant="text" sx={{ml:2}}>
                          <Button onClick={() => setQuoteId(post.id)} sx={{borderRight:'0 !important'}}><ThumbUpIcon sx={{color:'#057007'}} /></Button>
                          <Button className='Count' sx={{backgroundColor:'#39be52!important'}} onClick={handleLikequoteusers}>{post.likes}</Button>
                          <Button onClick={() => setQuoteId(post.id)} sx={{borderRight:'0 !important'}}><ThumbDownIcon sx={{color:'#e0610e'}} /></Button>
                          <Button className='Count' sx={{backgroundColor:'#e29f57 !important'}} onClick={handledisLikequoteusers}>{post.dislikes}</Button>
                        </ButtonGroup>
                        </Grid>
                        <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                        <Grid size={6}>
                          <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                            {post.author}
                          </Typography>
                        </Grid>

                      </Grid>
                    </Box></>
                );
              })}</Box> : <Box><p>No users found</p></Box>
            }

          </Box></> : <><Box>
            {posts.map((post) => {
              return (
                <>
                  <Box {...defaultProps} sx={{ my: 3, p: 0, mx:0 }} borderRadius={4} key={post.id}>
                    <Grid container spacing={2}>
                      <Grid size={11} sx={{ p: 3 }}>
                        <Typography variant="subtitle1" align='left'>
                          {post.quote}
                        </Typography>
                      </Grid>
                      {userId == post.user.id ?
                        <Grid size={1} sx={{ width: 42, height: 27, backgroundColor: "#90b021", mt: 0.6, borderRadius: 2 }}>
                          <PersonAddIcon sx={{ color: "#ffffff" }} />
                        </Grid> : null}
                      <Grid size={3}>
                        <ButtonGroup variant="text" sx={{ml:2}}>
                          <Button onClick={() => setQuoteId(post.id)} sx={{borderRight:'0 !important'}}><ThumbUpIcon sx={{color:'#057007'}} /></Button>
                          <Button className='Count' sx={{backgroundColor:'#39be52!important'}} onClick={handleLikequoteusers}>{post.likes}</Button>
                          <Button onClick={() => setQuoteId(post.id)} sx={{borderRight:'0 !important'}}><ThumbDownIcon sx={{color:'#e0610e'}} /></Button>
                          <Button className='Count' sx={{backgroundColor:'#e29f57 !important'}} onClick={handledisLikequoteusers}>{post.dislikes}</Button>
                        </ButtonGroup>
                      </Grid>
                      <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                      <Grid size={6}>
                        <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                          {post.author}
                        </Typography>
                      </Grid>

                    </Grid>
                  </Box></>
              );
            })}</Box></>}

      </Card>
    </Box>
      <Dialog
        open={open}
        //onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event: React.FormEvent<HTMLFormElement>) => {
            event.preventDefault();
            //handleClose();
          },
        }}
      >
        <DialogTitle>Add Quote</DialogTitle>
        <Box className="add-post-container" sx={{ mx: 4 }}>
          <form onSubmit={handleSubmitQutoes}>
            <TextField
              sx={{ my: 2 }}
              id="outlined-multiline-static"
              label="Quote"
              multiline
              rows={4}
              defaultValue="Default Value"
              fullWidth
              value={quote}
              onChange={(e) => setQuote(e.target.value)}
            />
            <TextField
              sx={{ my: 2 }}
              id="outlined-textarea"
              label="Author"
              placeholder="Placeholder"
              multiline
              fullWidth
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
            />
            <TextField
              sx={{ my: 2 }}
              id="outlined-textarea"
              label="Tags"
              placeholder="Placeholder"
              multiline
              fullWidth
              value={tags}
              onChange={(e) => setTags(e.target.value)} />
            <Button variant="contained" type="submit" startIcon={<SaveIcon />} sx={{ mb: 2, mr: 2, backgroundColor: '#509c04' }}>Save</Button>
            <Button variant="contained" color="secondary" startIcon={<CloseIcon />} sx={{ mb: 2, backgroundColor: '#d32f2f' }} onClick={handleClose}>Cancel</Button>
          </form>
        </Box>
      </Dialog>
      <BootstrapDialog
        onClose={handlViewCountClose}
        aria-labelledby="customized-dialog-title"
        open={openViewCount}
      >
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          People who reacted
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handlViewCountClose}
          sx={(theme) => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent dividers>
        <Box sx={{ width: '400', typography: 'body1' }}>
          <TabContext value={value}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <TabList variant="fullWidth" onChange={slectTab} aria-label="tabs">
                <Tab label={'Liked'} icon={<ThumbUpIcon sx={{color:'#057007'}} />} sx={{color:'#057007'}} value="1" />
                <Tab label={'DisLiked'} icon={<ThumbDownIcon sx={{color:'#e0610e'}} />} sx={{color:'#e0610e'}} value="2" />
              </TabList>
            </Box>
            <TabPanel value="1" sx={{minWidth:380}}>
            {likequoteusers.map((likeUser) => {
                return (<Box>{likeUser.user.firstName} {likeUser.user.lastName}</Box>)})}
            </TabPanel>
            <TabPanel value="2" sx={{minWidth:380}}>
            {dislikequoteusers.map((dislikeUser) => {
                return (<Box>{dislikeUser.user.firstName} {dislikeUser.user.lastName}</Box>)})}
            </TabPanel>
          </TabContext>
        </Box>
        </DialogContent>
      </BootstrapDialog>
    </>
  );
}

export default Quotes;