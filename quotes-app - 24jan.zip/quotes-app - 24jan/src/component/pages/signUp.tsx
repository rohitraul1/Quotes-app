import React from 'react';
import { useState } from 'react';
import { Box, TextField, Button, Typography, Card, FormControl, FormLabel, Alert, Stack, styled } from '@mui/material';
import axios from 'axios';
import MuiCard from '@mui/material/Card';


function SignUp() {


  // const [postsquote, setPostsquote] = useState<any[]>([]);
  // const [quotedata, setQuotedata] = useState({quote: "",author: "",tags: "",})
  const [firstnameError, setFirstnameError] = React.useState(false);
  const [firstnameErrorMessage, setFirstnameErrorMessage] = React.useState('');
  const [lastNameError, setLastNameError] = React.useState(false);
  const [lastNameErrorMessage, setLastNameErrorMessage] = React.useState('');
  const [emailError, setEmailError] = React.useState(false);
  const [emailErrorMessage, setEmailErrorMessage] = React.useState('');
  const [passwordError, setPasswordError] = React.useState(false);
  const [passwordErrorMessage, setPasswordErrorMessage] = React.useState('');
  const [statumessage, setStatumessage] = useState('');
  const [userdata, setUserdata] = useState({firstName: "",lastName: "", email: "", password: "",})
  const [errorMessage, setErrorMessage] = useState('');

  const [errordata, setErrordata] = useState<any[]>([]);

  const signupUrl = axios.create({
    baseURL: `http://localhost:4000/auth/sign-up`,
  });
  

  const validateInputs = () => {
    const firstname = document.getElementById('firstname') as HTMLInputElement;
    const lastname = document.getElementById('lastname') as HTMLInputElement;
    const email = document.getElementById('email') as HTMLInputElement;
    const password = document.getElementById('password') as HTMLInputElement;

    let isValid = true;

    if (firstname.value === '') {
      setFirstnameError(true);
      setFirstnameErrorMessage('Please enter a first name.');
      isValid = false;
    } else {
      setFirstnameError(false);
        setFirstnameErrorMessage('');
    }

    if (lastname.value === '') {
      setLastNameError(true);
      setLastNameErrorMessage('Please enter a last name.');
      isValid = false;
    } else {
      setLastNameError(false);
      setLastNameErrorMessage('');
    }

    if (!email.value || !/\S+@\S+\.\S+/.test(email.value)) {
        setEmailError(true);
        setEmailErrorMessage('Please enter a valid email address.');
        isValid = false;
    } else {
        setEmailError(false);
        setEmailErrorMessage('');
    }

    if (!password.value || password.value.length < 8) {
        setPasswordError(true);
        setPasswordErrorMessage('Password must be at least 8 characters long.');
        isValid = false;
    } else {
        setPasswordError(false);
        setPasswordErrorMessage('');
    }

    return isValid;
};

    //Add quote data
    const handleChange = (e: any) => {
      setUserdata({ ...userdata, [e.target.name]: e.target.value });
    }
    const handleregister = (e: { preventDefault: () => void; }) => {
      e.preventDefault();
      handleSignup();
  };
  // Sign Up API
  const handleSignup = async () => {

    try {
      let response = await signupUrl.post('', {
        ...userdata
      })
      setErrordata(response.data);
      console.log(errordata, "sjndkjaskdsakndkasjdk");
      if (response.status === 201) {
        setStatumessage('User registered successfully!');
      } else {
        setStatumessage('Registration failed. Please try again.');
      }
      // if (response.status === 400) {
      //   console.log("sjndkjaskdsakndkasjdk");
      //   //setErrordata(response);
      //   console.log(response.request.response,"sjndkjaskdsakndkasjdk");
      // }
      setUserdata({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
      })
    } catch (error) {
      console.log(error);
      if (error instanceof Error) {
        setErrorMessage(error.message);
    }
    }
  };

  const Card = styled(MuiCard)(({}) => ({
    display: 'flex',
    flexDirection: 'column',
    alignSelf: 'center',
    width: '100%',
    padding: 30,
    gap: 30,
    margin: 'auto',
    maxWidth: '450px',
    boxShadow:
        'hsla(220, 30%, 5%, 0.05) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px',
}));

  const SignInContainer = styled(Stack)(({}) => ({
    height: 'calc((1 - var(--template-frame-height, 0)) * 80dvh)',
    minHeight: '100%',
    padding: 30,
    '&::before': {
        content: '""',
        display: 'block',
        position: 'absolute',
        zIndex: -1,
        inset: 0,
        backgroundImage:
            'radial-gradient(ellipse at 50% 50%, hsl(210, 100%, 97%), hsl(0, 0%, 100%))',
        backgroundRepeat: 'no-repeat',
    },
}));


  return (
    <SignInContainer direction="column" justifyContent="space-between">
            <Card variant="outlined">
                <Typography
                    component="h1"
                    variant="h4"
                    sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)' }}>Sign Up</Typography>
                <Box
                    component="form"
                    onSubmit={handleregister}
                    noValidate
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        width: '100%',
                        gap: 2,
                    }}
                >
                   <FormControl>
                        <FormLabel sx={{alignSelf:'flex-start',ml:1}}>First Name</FormLabel>
                        <TextField
                            sx={{ textAlign: 'left' }}
                            error={firstnameError}
                            helperText={firstnameErrorMessage}
                            id="firstname"
                            type="text"
                            name="firstName"
                            placeholder="First Name"
                            autoFocus
                            required
                            fullWidth
                            variant="outlined"
                            color={firstnameError ? 'error' : 'primary'}
                            value={userdata.firstName}
                            onChange={handleChange}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel sx={{alignSelf:'flex-start',ml:1}}>Last Name</FormLabel>
                        <TextField
                            sx={{ textAlign: 'left' }}
                            error={lastNameError}
                            helperText={lastNameErrorMessage}
                            id="lastname"
                            type="text"
                            name="lastName"
                            placeholder="last Name"
                            autoFocus
                            required
                            fullWidth
                            variant="outlined"
                            value={userdata.lastName}
                            onChange={handleChange}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel htmlFor="email" sx={{alignSelf:'flex-start',ml:1}}>Email</FormLabel>
                        <TextField
                            sx={{ textAlign: 'left' }}
                            error={emailError}
                            helperText={emailErrorMessage}
                            id="email"
                            type="email"
                            name="email"
                            placeholder="your@email.com"
                            autoComplete="email"
                            autoFocus
                            required
                            fullWidth
                            variant="outlined"
                            color={emailError ? 'error' : 'primary'}
                            value={userdata.email}
                            onChange={handleChange}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel htmlFor="password" sx={{alignSelf:'flex-start',ml:1}}>Password</FormLabel>
                        <TextField
                            error={passwordError}
                            helperText={passwordErrorMessage}
                            name="password"
                            placeholder="Password"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            autoFocus
                            required
                            fullWidth
                            variant="outlined"
                            color={passwordError ? 'error' : 'primary'}
                            value={userdata.password}
                            onChange={handleChange}
                        />
                    </FormControl>
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        onClick={validateInputs}
                        sx={{backgroundColor:'#42bd82'}}
                    >
                        Sign Up
                    </Button>
                    {statumessage === '' ? 
                    null : <Alert>
                        {statumessage}
                    </Alert> 
                }
                </Box>
               
            </Card>
        </SignInContainer>
  );
}

export default SignUp;