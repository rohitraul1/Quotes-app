import { useEffect, useState } from 'react';
import { Box, Button, Grid, Typography } from '@mui/material';
import axios from "axios";
import { fetchPost } from '../common/apiService';

// URL
const quoteUrl = axios.create({
  baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
});

const token = sessionStorage.getItem('token');

const DATA = [
    {
        id: "131d994d-6c72-4ae3-ad28-fb4b0da25221",
        quote: "Without music, life would be a mistake.",
        author: "Friedrich Nietzsche",
        likes: 0,
        dislikes: 0,
        tags: "Music",

    },
    {
        id: "a3d61cf7-3b5d-400f-a6b4-1d307d901803",
        quote: "You only live once, but if you do it right, once is enough.",
        author: "Mae West",
        likes: 0,
        dislikes: 1,
        tags: "Humor",

    },
    {
        id: "2f43f7a0-4f69-429b-ac5b-3f3a7a179487",
        quote: "You must be the change you wish to see in the world.",
        author: "Mahatma Gandhi",
        likes: 1,
        dislikes: 1,
        tags: "test",

    },
];

const getRandomObject = (array: string | any[]) => {
  console.log(array.length,"array.length")
  const randomObject = array[Math.floor(Math.random() * array.length)];
  console.log("randomObject",randomObject )
  //setRandomData(randomObject)
  return randomObject;
};

function Home() {

  const [posts, setPosts] = useState<any[]>([]); 
  console.log("postsssss",posts )

  //const [randomData, setRandomData] = useState(async () => await getRandomObject(posts));
  const [randomData, setRandomData] = useState( () =>  getRandomObject(posts));
  console.log("random quotes",randomData )

  const handleLike = () => {
    getRandomObject(posts)
    console.log("handleLike",randomData )

  };

  const fetchPost = async () => {
    try {
      let response = await quoteUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPosts(response.data);
    } catch (error) {
    }
  };
  
  useEffect(() => {
    if(posts){
      console.log("inside posddddd", )
      getRandomObject(posts)
    }

    // const fetchPost = async () => {
    //   const result = await fetchPost();
    //   setPosts(result);
    // };

    fetchPost();
  }, []);


  return (
    <Grid>
    <Box
      sx={(theme) => ({
        boxShadow: 2,
        width: '40rem',
        bgcolor: '#fff',
        color: 'grey.800',
        p: 4,
        mx: 'auto',
        my: 15,
        borderRadius: 2,
        border: 1,
        borderColor: '#cfc100',
        textAlign: 'center',
        fontSize: '0.875rem',
        fontWeight: '700',
        fontStyle: 'italic',
        ...theme.applyStyles('dark', {
          bgcolor: '#101010',
          color: 'grey.300',
        }),
      })}
    > <div>
      {randomData ? 
         <><Typography variant="subtitle1" align='center' fontWeight={'bold'}>{randomData.quote}</Typography><Typography variant="body2" align='right'>{randomData.author}</Typography></>:null
    }
    <Button  onClick={ handleLike} sx={{ borderRight: '0 !important' }}>dsfdsfsdfsd</Button>

  </div>
      {/* {posts.map((post) => {
      return (
        <><Typography variant="subtitle1" align='center' fontWeight={'bold'}>
          {post.quote}
        </Typography><Typography variant="body2" align='right'>
            {post.author}
          </Typography></>
      );
    })} */}
    </Box> </Grid>
  );
}

export default Home;