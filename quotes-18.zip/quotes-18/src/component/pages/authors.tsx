import { Box, Card, Typography } from '@mui/material';
import axios from "axios";
import { useEffect, useState } from 'react';


function Authors() {
  const [authors, setAuthors] = useState<any[]>([]);
  const token = sessionStorage.getItem('token');

  const authorsUrl = axios.create({
    baseURL: 'http://localhost:4000/authors',
  });

  const defaultProps = {
    bgcolor: 'background.paper',
    m: 1,
    border: 1,
    boxShadow: 2,
    borderColor: '#cfc100',
  };

  useEffect(() => {
    const fetchPost = async () => {
      try {
        let response = await authorsUrl.get('', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        setAuthors(response.data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchPost();
  }, []);

  return (
    <><Box sx={{ minWidth: 275, mx: 8, }}></Box>
    <Typography
      component="h1"
      variant="h4"
      sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)', my: 2, textAlign: 'left' }}
    >Author</Typography>
    <Card elevation={3} sx={{ mx:8,}}>
        {authors.map((author) => {
          return (
            <Box {...defaultProps} sx={{ mx: 12, my: 3, p: 4 }} borderRadius={4} key={author.id}>
              <Typography variant="body2" align='right'>
                {author.author}
              </Typography>
            </Box>
          );
        })}
      </Card></>
  );
}

export default Authors;