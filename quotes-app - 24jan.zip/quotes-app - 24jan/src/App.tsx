
import './App.css';
import Login from './component/pages/login';
import AppBar from './component/common/appBar';
import Quotes from './component/pages/quotes';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import Home from 'component/pages/home';
import Authors from 'component/pages/authors';
import MyQuotes from 'component/pages/myQuotes';
import SignUp from 'component/pages/signUp';

function App() {
  return (
    <div className="App" >
      <Router>
        <AppBar />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/authors" element={<Authors />} />
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/myQuotes" element={<MyQuotes />} />
          <Route path="/signUp" element={<SignUp />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
