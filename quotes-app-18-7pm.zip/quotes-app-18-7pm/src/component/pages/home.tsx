import { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import axios from "axios";

// URL
const quoteUrl = axios.create({
  baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
});

const token = sessionStorage.getItem('token');



function Home() {

  const [posts, setPosts] = useState<any[]>([]); 

  useEffect(() => {
    const fetchPost = async () => {
      try {
        let response = await quoteUrl.get('', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        setPosts(response.data);
      } catch (error) {
      }
    };
    fetchPost();
    //getRandomQuote(posts);
  }, []);

  
// const getRandomQuote = (array: string | any[]) => {
//   const randomObject = array[Math.floor(Math.random() * array.length)];
//   setPosts(randomObject) ;
// };

//const shuffle = <T>(array: T[]) => { for (let i = array.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [array[i], array[j]] = [array[j], array[i]]; } return array; }; const shuffledObjects = shuffle(users); console.log(shuffledObjects);
  return (
    <Box
      sx={(theme) => ({
        boxShadow: 2,
        width: '40rem',
        bgcolor: '#fff',
        color: 'grey.800',
        p: 4,
        mx: 20,
        my: 20,
        borderRadius: 2,
        border: 1,
        borderColor: '#cfc100',
        textAlign: 'center',
        fontSize: '0.875rem',
        fontWeight: '700',
        fontStyle: 'italic',
        ...theme.applyStyles('dark', {
          bgcolor: '#101010',
          color: 'grey.300',
        }),
      })}
    >{posts.map((post) => {
      return (
        <><Typography variant="subtitle1" align='center' fontWeight={'bold'}>
          {post.quote}
        </Typography><Typography variant="body2" align='right'>
            {post.author}
          </Typography></>
      );
    })}
    </Box>
  );
}

export default Home;