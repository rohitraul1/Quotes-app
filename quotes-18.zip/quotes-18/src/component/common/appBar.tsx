import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';

import Grid from '@mui/system/Grid';
import { Avatar, IconButton, Menu, MenuItem, Tooltip, Typography } from '@mui/material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import {Navigate} from "react-router-dom";

const StyledToolbar = styled(Toolbar)(({ }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  flexShrink: 0,
  padding: '8px 12px',
  fontSize: 24,
  fontWeight: 'bold'
}));

export default function AppAppBar() {
  const token = sessionStorage.getItem('token');
  const firstName = sessionStorage.getItem('firstName');
  const lastName = sessionStorage.getItem('lastName');
  const settings = ['Logout'];
  const [anchorElUser, setAnchorElUser] = React.useState<null | HTMLElement>(null);
  const [gotoHome, setgotoHome] = React.useState(false);
  const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const handleLogout = () => {
    sessionStorage.clear();
  };

  if (gotoHome) {
    sessionStorage.clear();
    window.location.reload();
    return <Navigate to="/login" />;
  }

  return (
    <AppBar
      position="relative"
      enableColorOnDark
      sx={{
        boxShadow: 0,
        bgcolor: '#27c744',
        backgroundImage: 'none',
      }}
    >
      <Container maxWidth="lg">
        <StyledToolbar variant="dense" disableGutters>

          <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={2}>
              <Grid size={3}>
                <Box
                  sx={{
                    display: { xs: 'none', md: 'flex' },
                    gap: 1,
                    alignItems: 'center',
                  }}
                >Software Quotes</Box>
              </Grid>
              {token ?
                <Grid size={9}>
                  <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center', }}>
                    <Box sx={{ display: { xs: 'none', md: 'flex', color: '#000' } }}>
                      <Button href="/home" sx={{ color: '#000000' }}>
                        Home
                      </Button>
                      <Button href="/authors" sx={{ color: '#000000' }}>
                        Authors
                      </Button>
                      <Button href="/quotes" sx={{ color: '#000000' }}>
                        Quotes
                      </Button>
                      <Button href="/myquotes" sx={{ color: '#000000' }}>
                        My Quotes
                      </Button>
                    </Box>
                  </Box>
                </Grid> : null
              }
            </Grid>
          </Box>
          <Box
            sx={{
              display: { xs: 'none', md: 'flex' },
              gap: 1,
              alignItems: 'center',
            }}
          >
             {token ? null :
            <Button href="/quotes" sx={{ color: '#000000' }} size="small">
              Quotes
            </Button>}
            {token ?
            <Box sx={{ flexGrow: 0 }}>
            <Typography sx={{display:'inline',fontSize: 'clamp(0.7rem, 2vw, 1rem)', mr:1 }}>{firstName} {lastName}</Typography>
              <Tooltip title="Open settings">
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar /><ArrowDropDownIcon/>
                </IconButton>
              </Tooltip> 
              <Menu
                sx={{ mt: '45px' }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                    <MenuItem key={setting} onClick={() => {setgotoHome(true)}}>
                    <Button variant="text" onClick={handleLogout}>{setting}</Button>
                  </MenuItem>
                ))} 
              </Menu>
            </Box>:<Button href="/login" sx={{backgroundColor:'#81a426'}} variant="contained" size="small">
                Login / Sign up
              </Button>
            }
          </Box>
        </StyledToolbar>
      </Container>
    </AppBar>
  );
}
