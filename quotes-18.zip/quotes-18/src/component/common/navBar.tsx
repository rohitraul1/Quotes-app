import Button from '@mui/material/Button';


function NavBar() {
  return (
    <nav>
      <Button href="/quotes">Quotes</Button>
      <Button href="/login">Login</Button>
    </nav>
  );
}

export default NavBar;