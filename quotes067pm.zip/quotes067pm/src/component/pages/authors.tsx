import { Box, Button, Card, IconButton, InputBase, Link, Typography } from '@mui/material';
import axios from "axios";
import Grid from '@mui/system/Grid';
import { useEffect, useState } from 'react';
import AlphabetList from "react-alphabet-list";
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';

function Authors() {
  const [authors, setAuthors] = useState<any[]>([]);
  const [searchItem, setSearchItem] = useState('')
  const [filteredauthors, setFilteredAuthors] = useState<any[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [filteredData, setFilteredData] = useState<any[]>([]);

  const token = sessionStorage.getItem('token');
  //const data = [{ id:1,author: "anything" },{ id:2,author: "bdfsdfs" },{ id:3,author: "cgfdgds" },{ id:4,author: "dfagdg" },{ id:5,author: "fsdgsdffds" }];
  //const data = ["anything", "bdfsdfs", "cgfdgds", "dfagdg", "esdgsdffds", "fsdgsdffds", "gsdgsdffds", "hsdgsdffds", "isdgsdffds", "jsdgsdffds", "ksdgsdffds", "lsdgsdffds", "msdgsdffds", "nsdgsdffds", "osdgsdffds", "psdgsdffds", "qsdgsdffds", "rsdgsdffds", "ssdgsdffds", "tsdgsdffds", "usdgsdffds", "vsdgsdffds", "xsdgsdffds", "ysdgsdffds", "zsdgsdffds"];
  //const data = [{ name: "anything" }];
  //const nameKey = "author";
  const authorsUrl = axios.create({
    baseURL: 'http://localhost:4000/authors',
  });

  const quoteUrl = axios.create({
    baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
  });
  
  const navigate = useNavigate()

  const handleInputChange = (e: { target: { value: any; }; }) => { 
    const searchTerm = e.target.value;
    setSearchItem(searchTerm)
    const filteredItems = authors.filter((user: { author: string; }) =>
    user.author.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredAuthors(filteredItems);
  }

  const data=[
    {
    "id": "131d994d-6c72-4ae3-ad28-fb4b0da25221",
    "quote": "Without music, life would be a mistake.",
    "author": "Friedrich Nietzsche",
    "likes": 0,
    "dislikes": 1,
    "tags": "Music",
    "user": {
        "id": "533a5f11-4782-47a3-a438-3fb92f9bcb72",
        "firstName": "Rohan",
        "lastName": "sharma",
        "email": "rohansharma@gmail.com",
        "deletedAt": null
    }
},
{
    "id": "a3d61cf7-3b5d-400f-a6b4-1d307d901803",
    "quote": "You only live once, but if you do it right, once is enough.",
    "author": "Mae West",
    "likes": 0,
    "dislikes": 1,
    "tags": "Humor",
    "user": {
        "id": "beb288d7-8500-4d64-9f4d-2f9078d321cc",
        "firstName": "Rohit",
        "lastName": "Raul",
        "email": "rohit.raul@creativecapsule.com",
        "deletedAt": null
    }
},
{
    "id": "2f43f7a0-4f69-429b-ac5b-3f3a7a179487",
    "quote": "You must be the change you wish to see in the world.",
    "author": "Mahatma Gandhi",
    "likes": 1,
    "dislikes": 2,
    "tags": "test",
    "user": {
        "id": "beb288d7-8500-4d64-9f4d-2f9078d321cc",
        "firstName": "Rohit",
        "lastName": "Raul",
        "email": "rohit.raul@creativecapsule.com",
        "deletedAt": null
    }
},]

const getFilteredDataByAuthor = (searchItem: string) => {
  console.log(posts, "ALL quotes data ")
 
  const authorData = posts.filter((item) => item.author.toLowerCase().includes(searchItem.toLowerCase()));
  console.log(authorData, "Filter data on selected Author")
  //setFilteredData(authorData);
  console.log(filteredData, "Filter data by Author")

  //handleChange1();
  navigate("/quotes", {state:{name:authorData ?? []}})
};

  const handleChange = (authorName: any) => {
    getFilteredDataByAuthor(authorName);
    //navigate("/quotes", {state:{name:authorName}})
    
  }

  const handleChange1 = () => {
    navigate("/quotes", {state:{name:filteredData}})
    
  }

  const defaultProps = {
    borderBottom: 1,
    px: 3,
    borderColor: '#88c292',
    minWidth: 600
  };

  const fetchAuthors = async () => {
    try {
      let response = await authorsUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setAuthors(response.data);
      setFilteredAuthors(response.data)
    } catch (error) {
      console.log(error);
    }
  };

  const fetchPost = async () => {
    try {
      let response = await quoteUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPosts(response.data);
    } catch (error) {
      console.log(error);
    }
  };


  useEffect(() => {
    fetchAuthors();
    fetchPost();
  }, []);

  return (
    <><Grid container sx={{ minWidth: 275, my: 3, display: 'inline-flex', mx: 9 }}>
      <Grid size={12}>
        <Typography
          component="h1"
          variant="h4"
          sx={{ width: '90%', fontSize: 25, my: 2, pl: 1, textAlign: 'left' }}>Author</Typography>
      </Grid>
      <Grid size={12}>
        <Card elevation={3}>
        <InputBase
                  type="text"
                  sx={{flex: 1,width:'96%', marginTop:2, border:'1px solid #ccc', p:1, }}
                  placeholder="Search"
                  inputProps={{ 'aria-label': 'search' }}
                  value={searchItem}
                  onChange={handleInputChange}
                />
                {/* <IconButton type="button" sx={{ p: '10px', backgroundColor: '#b1ac16', '&:hover': { backgroundColor: '#736f09' }, color: '#ffffff' }} aria-label="search" onClick={handleInputChange}>
                  <SearchIcon />
                </IconButton> */}
        {filteredauthors.length === 0 ? <Box sx={{minWidth:600, my:3}}>No Author found</Box> : 
         <> {filteredauthors.map((author) => {
            return (
              <Box {...defaultProps} sx={{ p: 1 }} key={author.id}>

                <Typography variant="body2" align='left' sx={{ py: 1, ml:1 }}>
                <Button color="inherit" onClick={event => { handleChange(author.author) }}>{author.author}</Button>
                </Typography>
              </Box>
            );
          })}</>}

        </Card></Grid></Grid></>
  );
}

export default Authors;