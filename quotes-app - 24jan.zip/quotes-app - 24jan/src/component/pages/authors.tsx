import { Card, Grid, Typography } from '@mui/material';
import axios from "axios";
import { useEffect, useState } from 'react';
import AlphabetList from "react-alphabet-list";
import '../../App.css';
//import { Tag, Icon } from "antd";
function Authors() {
  const [authors, setAuthors] = useState<any[]>([]);
  const token = sessionStorage.getItem('token');
  //const data = [{ id:1,author: "anything" },{ id:2,author: "bdfsdfs" },{ id:3,author: "cgfdgds" },{ id:4,author: "dfagdg" },{ id:5,author: "fsdgsdffds" }];
  //const data = ["anything", "bdfsdfs", "cgfdgds", "dfagdg", "esdgsdffds", "fsdgsdffds", "gsdgsdffds", "hsdgsdffds", "isdgsdffds", "jsdgsdffds", "ksdgsdffds", "lsdgsdffds", "msdgsdffds", "nsdgsdffds", "osdgsdffds", "psdgsdffds", "qsdgsdffds", "rsdgsdffds", "ssdgsdffds", "tsdgsdffds", "usdgsdffds", "vsdgsdffds", "xsdgsdffds", "ysdgsdffds", "zsdgsdffds"];
  const data = [{ name: "anything" }];
const nameKey = "name";
  //const nameKey = "id";
  const authorsUrl = axios.create({
    baseURL: 'http://localhost:4000/authors',
  });

  const defaultProps = {
    bgcolor: 'background.paper',
    m: 1,
    border: 1,
    boxShadow: 2,
    borderColor: '#cfc100',
  };

 

  useEffect(() => {
    const fetchPost = async () => {
      try {
        let response = await authorsUrl.get('', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        setAuthors(response.data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchPost();
  }, [authors]);

  return (
    <Grid container sx={{ minWidth: 275, my: 3, display: 'inline-flex' }}>
      <Typography
        component="h1"
        variant="h4"
        sx={{ width: '100%', fontSize: 25, my: 2, textAlign: 'left' }}
      >Author</Typography>
      <Card elevation={3} sx={{ mx: 8, }}>
        <div className="app">
        <AlphabetList
  data={data}
  nameKey={nameKey}
 // style={{}}
  alphabetListStyle={{}}
  alphabetItemStyle={{}}
  generateFn={(item, index) => {
    return <div key={item}>{item}</div>;
  }}
/>
        </div>
        {/* {authors.map((author) => {
          return (
            <Box {...defaultProps} sx={{ mx: 12, my: 3, p: 4 }} borderRadius={4} key={author.id}>
              <Typography variant="body2" align='right'>
                {author.author}
              </Typography>
            </Box>
          );
        })} */}

      </Card></Grid>
  );
}

export default Authors;