import axios from 'axios';
const token = sessionStorage.getItem('token');
const quoteUrl = axios.create({
  baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
});

export const fetchPost = async () => {
  try {
    let response = await quoteUrl.get('', {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    console.log('Error fetching data:', error);
  }
};