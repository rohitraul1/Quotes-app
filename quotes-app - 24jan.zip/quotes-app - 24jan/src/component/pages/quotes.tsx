import React, { useEffect, useState } from 'react';
import { Card, Typography, Box, Button, Dialog, DialogTitle, TextField, IconButton, styled, Paper, InputBase, MenuItem, Stack, ButtonGroup, DialogContent, Chip } from '@mui/material';
import axios from "axios";
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import Grid from '@mui/system/Grid';
import Badge, { BadgeProps } from '@mui/material/Badge';
import SaveIcon from '@mui/icons-material/Save';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

const defaultProps = {
  bgcolor: 'background.paper',
  m: 1,
  border: 1,
  boxShadow: 2,
  borderColor: '#cfc100',
};

function Quotes() {

  const [open, setOpen] = React.useState(false);
  const [openViewCount, setOpenViewCount] = React.useState(false);
  const [postsquote, setPostsquote] = useState<any[]>([]);
  const token = sessionStorage.getItem('token');
  const [posts, setPosts] = useState<any[]>([]);
  const userId = sessionStorage.getItem('userId');
  const [searchItem, setSearchItem] = useState('')
  const [dropdownOption, setDropdownOption] = useState('')
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [value, setValue] = React.useState('1');
  const [quoteId, setQuoteId] = React.useState();
  const [likequoteusers, setLikequoteusers] = useState<any[]>([]);
  const [dislikequoteusers, setDislikequoteusers] = useState<any[]>([]);
  const [quotedata, setQuotedata] = useState({quote: "",author: "",tags: "",})

  const [quoteerror, setQuoteerror] = React.useState(false);
  const [quoteerrorMessage, setQuoteerrorMessage] = React.useState('');
  const [authorerror, setAuthorerror] = React.useState(false);
  const [authorerrorMessage, setAuthorerrorMessage] = React.useState('');

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const quoteUrl = axios.create({
    baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
  });

  const quotelikebyuserUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}/like/users`
  });

  const quotedislikebyuserUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}/dislike/users`
  });

  // const likeQuoteUrl = axios.create({
  //   baseURL: `http://localhost:4000/quotes/${quoteId}/like/up/`, 
  // });

  //Update Delete QuoteID values
  //   const updatelikeQuoteID = async (quoteId: any,) => {
  //     setQuoteId(quoteId);
  //    handleLikequoteByusers();
  // };


  const validateInputs = () => {
    const quote = document.getElementById('quote') as HTMLInputElement;
    const author = document.getElementById('author') as HTMLInputElement;

    let isValid = true;

    if (quote.value === '') {
      setQuoteerror(true);
      setQuoteerrorMessage('quote should not be empty.');
      isValid = false;
    } else if (quote.value.toString().length <= 3){
      setQuoteerror(true);
      setQuoteerrorMessage('quote must be longer than or equal to 4 characters');

    } else
    {
      setQuoteerror(false);
      setQuoteerrorMessage('');
    }

    if (author.value === '') {
      setAuthorerror(true);
      setAuthorerrorMessage('author should not be empty.');
      isValid = false;
    } else if (author.value.toString().length <= 1){
      setAuthorerror(true);
      setAuthorerrorMessage('author must be longer than or equal to 2 characters');

    }else {
      setAuthorerror(false);
      setAuthorerrorMessage('');
    }

    return isValid;
};

  const handleLikequoteByusers = async (quoteId: any) => {
    try {
      const response = await axios.get(`http://localhost:4000/quotes/${quoteId}/like/users`, {})
      setLikequoteusers(response.data);
    } catch (error) {
    }
    setOpenViewCount(true);
  };

  const handleDislikequoteByusers = async (quoteId: any) => {
    try {
      const response = await axios.get(`http://localhost:4000/quotes/${quoteId}/dislike/users`, {})
      setDislikequoteusers(response.data);
    } catch (error) {
    }
    setOpenViewCount(true);
  };

  const handlViewCountClose = () => {
    setOpenViewCount(false);
  };

  const handleInputChange = () => {
    filterData(searchItem);
  }

  const filterData = (searchItem: string) => {
    if (dropdownOption.toLowerCase() == "author") {
      getFilteredDataByAuthor(searchItem);
    } else if (dropdownOption.toLowerCase() == "quote") {
      getFilteredDataByQuote(searchItem)
    } else {
      getFilteredDataByTag(searchItem)
    }
  };

  const getFilteredDataByAuthor = (searchItem: string) => {
    const authorData = posts.filter((item) => item.author.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(authorData);
  };

  const getFilteredDataByQuote = (searchItem: string) => {
    const quoteData = posts.filter((item) => item.quote.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(quoteData);
  };

  const getFilteredDataByTag = (searchItem: string) => {
    const tagData = posts.filter((item) => item.tags.toLowerCase().includes(searchItem.toLowerCase()));
    setFilteredData(tagData);
  };

  // Sumit qoutes
  const handleSubmitQutoes = (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    addPostsqutoes();
  };

  //Add quote data
  const handleChange = (e: any) => {
    setQuotedata({ ...quotedata, [e.target.name]: e.target.value });
  }

  // POST with Axios Qutoes
  const addPostsqutoes = async () => {

    try {
      let response = await quoteUrl.post('', {
        ...quotedata
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPostsquote([response.data, ...postsquote]);
      handleClose();
      setQuotedata({
        quote: "",
        author: "",
        tags: "",
      })
    } catch (error) {
      console.log(error);
    }
  };

  const slectTab = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const fetchPost = async () => {
    try {
      let response = await quoteUrl.get('',
        // {
        //   headers: {
        //     'Content-Type': 'application/json',
        //     'Authorization': `Bearer ${token}`
        //   }
        // }
      );
      setFilteredData([]);
      setDropdownOption('');
      setSearchItem('');
      setPosts(response.data);
    } catch (error) {
    }
  };

  useEffect(() => {
    fetchPost();
  }, []);

  const StyledBadge = styled(Badge)<BadgeProps>(({ theme }) => ({
    '& .MuiBadge-badge': {
      right: -3,
      top: 13,
      border: `2px solid ${theme.palette.background.paper}`,
      padding: '0 4px',
    },
  }));

  const dropdown = [
    {
      value: 'author',
      label: 'Author',
    },
    {
      value: 'quote',
      label: 'Quote',
    },
    {
      value: 'tags',
      label: 'Tags',
    }
  ];

  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
      padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));


  //Like Quotes API
  const handleLike = async (quoteId: any, likedcount: any) => {
    try {
      if (likedcount == 0) {
        const response = await axios.patch(`http://localhost:4000/quotes/${quoteId}/like/up/`, {}, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        })
      } else {
        const response = await axios.patch(`http://localhost:4000/quotes/${quoteId}/like/down/`, {}, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        })
      }
      fetchPost();
    } catch (error) {
      console.log(error);
    }
  };

  //DisLike Quotes API
  const handledisLike = async (quoteId: any, dislikeCount: any) => {
    try {
      if (dislikeCount == 0) {
        const response = await axios.patch(`http://localhost:4000/quotes/${quoteId}/dislike/up/`, {}, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        })
      } else {
        const response = await axios.patch(`http://localhost:4000/quotes/${quoteId}/dislike/down/`, {}, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        })
      }
      fetchPost();
    } catch (error) {
      console.log(error);
    }
  };

  return (

    <><Box sx={{ minWidth: 275, my: 3, mx: 8, }}>
      <Typography
        component="h1"
        variant="h4"
        sx={{ width: '100%', fontSize: 25, my: 2, ml: 1, textAlign: 'left' }}
      >Quotes</Typography>
      <Card elevation={3} sx={{ my: 2, px: 12, py: 3 }}>
        {token ? <Grid container>
          <Grid size={8}>
            <Stack spacing={2} direction="row">
              <TextField
                select
                label="Select"
                defaultValue=""
                onChange={(e) => setDropdownOption(e.target.value)}
                sx={{ width: 200 }}
              >
                {dropdown.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
              <Paper
                component="form"
                sx={{ mt: 3, ml: 12, p: '2px 4px', display: 'flex', alignItems: 'center', width: 400, height: 52 }}
              >
                <InputBase
                  type="text"
                  sx={{ ml: 1, flex: 1 }}
                  placeholder="Search"
                  inputProps={{ 'aria-label': 'search' }}
                  onChange={(e) => setSearchItem(e.target.value)}
                />
                <IconButton type="button" sx={{ p: '10px', backgroundColor: '#b1ac16', '&:hover': { backgroundColor: '#736f09' }, color: '#ffffff' }} aria-label="search" onClick={handleInputChange}>
                  <SearchIcon />
                </IconButton>
              </Paper>
              <Button onClick={fetchPost}><RefreshIcon sx={{ fontSize: 40, color: '#27c744' }} /></Button>
            </Stack>
          </Grid>
          <Grid size={4}>
            <Button variant="contained" onClick={handleClickOpen} sx={{ mt: 1, backgroundColor: '#b1ac16', width: 'auto', ml: 'auto' }}>
              <AddIcon /> Add Quote
            </Button>
          </Grid></Grid> : null}
        {filteredData.length >= 1 ?
          <><Box>
            {filteredData.length >= 1 ?
              <Box>{filteredData.map((post) => {
                return (
                  <>
                    <Box {...defaultProps} sx={{ my: 3, p: 0, mx: 0 }} borderRadius={4} key={post.id}>
                      <Grid container spacing={2}>
                        <Grid size={11} sx={{ p: 3 }}>
                          <Typography variant="subtitle1" align='left'>
                            {post.quote}
                          </Typography>
                        </Grid>
                        {userId == post.user.id ?
                          <Grid size={1} sx={{ width: 42, height: 27, backgroundColor: "#90b021", mt: 0.6, borderRadius: 2 }}>
                            <PersonAddIcon sx={{ color: "#ffffff" }} />
                          </Grid> : null}
                        <Grid size={3}>
                          <ButtonGroup variant="text" sx={{ ml: 2 }}>
                            <Button disabled={(userId == post.user.id)} onClick={event => { handleLike(post.id, post.likes) }} sx={{ borderRight: '0 !important' }}><ThumbUpIcon sx={{ color: '#057007' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#39be52!important' }} onClick={event => { handleLikequoteByusers(post.id) }}>{post.likes}</Button>
                            <Button disabled={(userId == post.user.id)} onClick={event => { handledisLike(post.id, post.dislikes) }} sx={{ borderRight: '0 !important' }}><ThumbDownIcon sx={{ color: '#e0610e' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#e29f57 !important' }} onClick={event => { handleDislikequoteByusers(post.id) }}>{post.dislikes}</Button>
                          </ButtonGroup>
                        </Grid>
                        <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                        <Grid size={6}>
                          <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                            {post.author}
                          </Typography>
                        </Grid>

                      </Grid>
                    </Box></>
                );
              })}</Box> : <Box><p>No users found</p></Box>
            }

          </Box></> : <><Box>
            {posts.map((post) => {
              return (
                <>
                  <Box {...defaultProps} sx={{ my: 3, p: 0, mx: 0 }} borderRadius={4} key={post.id}>
                    <Grid container spacing={2}>
                      <Grid size={11} sx={{ p: 3 }}>
                        <Typography variant="subtitle1" align='left'>
                          {post.quote}
                        </Typography>
                      </Grid>
                      {userId == post.user.id ?
                        <Grid size={1} sx={{ width: 47, height: 30, backgroundColor: "#90b021", mt: 0.1, borderRadius: 4 }}>
                          <PersonAddIcon sx={{ color: "#ffffff" }} />
                        </Grid> : null}
                      <Grid size={3}>
                        <ButtonGroup variant="text" sx={{ ml: 2 }}>
                          <Button disabled={(userId == post.user.id)} onClick={event => { handleLike(post.id, post.likes) }} sx={{ borderRight: '0 !important' }}><ThumbUpIcon sx={{ color: '#057007' }} /></Button>
                          <Button className='Count' sx={{ backgroundColor: '#39be52!important' }} onClick={event => { handleLikequoteByusers(post.id) }}>{post.likes}</Button>
                          <Button disabled={(userId == post.user.id)} onClick={event => { handledisLike(post.id, post.dislikes) }} sx={{ borderRight: '0 !important' }}><ThumbDownIcon sx={{ color: '#e0610e' }} /></Button>
                          <Button className='Count' sx={{ backgroundColor: '#e29f57 !important' }} onClick={event => { handleDislikequoteByusers(post.id) }}>{post.dislikes}</Button>
                        </ButtonGroup>
                      </Grid>
                      <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                      <Grid size={6}>
                        <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                          {post.author}
                        </Typography>
                      </Grid>

                    </Grid>
                  </Box></>
              );
            })}</Box></>}

      </Card>
    </Box>
      <Dialog
        open={open}
      >
        <DialogTitle>Add Quote</DialogTitle>
        <Box className="add-post-container" sx={{ mx: 4 }}>
          <form onSubmit={handleSubmitQutoes}>
            <TextField
              sx={{ my: 2 }}
              error={quoteerror}
              helperText={quoteerrorMessage}
              id="quote"
              label="Quote"
              multiline
              rows={4}
              defaultValue="Default Value"
              fullWidth
              name="quote"
              value={quotedata.quote}
              onChange={handleChange}
            />
            <TextField
              sx={{ my: 2 }}
              error={authorerror}
              helperText={authorerrorMessage}
              id="author"
              label="Author"
              placeholder="Placeholder"
              multiline
              fullWidth
              name="author"
              value={quotedata.author}
              onChange={handleChange}
            />
            <TextField
              sx={{ my: 2 }}
              id="tags"
              label="Tags"
              placeholder="Placeholder"
              multiline
              fullWidth
              name="tags"
              value={quotedata.tags}
              onChange={handleChange} />
            <Grid sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
              <Button variant="contained" type="submit" startIcon={<SaveIcon />} sx={{ mr: 2, backgroundColor: '#509c04' }} onClick={validateInputs}>Save</Button>
              <Button variant="contained" color="secondary" startIcon={<CloseIcon />} sx={{ backgroundColor: '#d32f2f' }} onClick={handleClose}>Cancel</Button>
            </Grid>
          </form>
        </Box>
      </Dialog>
      <BootstrapDialog
        onClose={handlViewCountClose}
        aria-labelledby="customized-dialog-title"
        open={openViewCount}
      >
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          People who reacted
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handlViewCountClose}
          sx={(theme) => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent dividers>
          <Box sx={{ width: '400', typography: 'body1' }}>
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <TabList variant="fullWidth" onChange={slectTab} aria-label="tabs">
                  <Tab label={'Liked'} icon={<ThumbUpIcon sx={{ color: '#057007' }} />} sx={{ color: '#057007' }} value="1" />
                  <Tab label={'DisLiked'} icon={<ThumbDownIcon sx={{ color: '#e0610e' }} />} sx={{ color: '#e0610e' }} value="2" />
                </TabList>
              </Box>
              <TabPanel value="1" sx={{ minWidth: 380 }}>
                {likequoteusers.map((likeUser) => {
                  return (<Box>{likeUser.user.firstName} {likeUser.user.lastName}</Box>)
                })}
              </TabPanel>
              <TabPanel value="2" sx={{ minWidth: 380 }}>
                {dislikequoteusers.map((dislikeUser) => {
                  return (<Box>{dislikeUser.user.firstName} {dislikeUser.user.lastName}</Box>)
                })}
              </TabPanel>
            </TabContext>
          </Box>
        </DialogContent>
      </BootstrapDialog>
    </>
  );
}

export default Quotes;