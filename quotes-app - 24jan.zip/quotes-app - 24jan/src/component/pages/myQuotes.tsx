import React, { useEffect, useState } from 'react';
import { Badge, BadgeProps, Box, Button, ButtonGroup, Card, Chip, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Stack, styled, TextField, Typography } from '@mui/material';
import Grid from '@mui/system/Grid';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import axios from "axios";
import '../../App.css';
import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/Save';


const defaultProps = {
  bgcolor: 'background.paper',
  m: 1,
  border: 1,
  boxShadow: 2,
  borderColor: '#cfc100',
};

const StyledBadge = styled(Badge)<BadgeProps>(({ theme }) => ({
  '& .MuiBadge-badge': {
    right: -3,
    top: 13,
    border: `2px solid ${theme.palette.background.paper}`,
    padding: '0 4px',
  },
}));

function MyQuotes() {

  const [value, setValue] = React.useState('1');
  const [posts, setPosts] = useState<any[]>([]);
  const [likesquotes, setLikesQuotes] = useState<any[]>([]);
  const [dislikesquotes, setDisLikesQuotes] = useState<any[]>([]);
  const [open, setOpen] = React.useState(false);
  const [delAlertOpen, setDeleteAlertOpen] = React.useState(false);
  const [quoteId, setQuoteId] = React.useState(0);
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const token = sessionStorage.getItem('token');
  const userId = sessionStorage.getItem('userId');

  const quoteUrl = axios.create({
    baseURL: process.env.REACT_APP_API_URL_FETCH_QUOTES
  });

  const quoteByloggedInUserUrl = axios.create({
    baseURL: `http://localhost:4000/users/${userId}/quotes`,
  });
  const favouriteQuoteUrl = axios.create({
    baseURL: `http://localhost:4000/users/${userId}/favourite-quotes`,
  });
  const unfavouriteQuoteUrl = axios.create({
    baseURL: `http://localhost:4000/users/${userId}/unfavourite-quotes`,
  });
  const likeQuoteUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}/like/up/`,
  });
  const editQuoteUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/${quoteId}`,
  });
  const deleteQuoteUrl = axios.create({
    baseURL: `http://localhost:4000/quotes/`,
  });

  const slectTab = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const StyledtabBadge = styled(Badge)<BadgeProps>(({ theme }) => ({
    '& .MuiBadge-badge': {
      right: -26,
      top: 9,
      border: `1px solid ${theme.palette.background.paper}`,
      padding: '0 4px',
      height: '30px',
      borderRadius: '20px',
      minWidth: '30px',
      backgroundColor: '#565d1e',
      color: '#ffffff'
    },
  }));


  //Delete Quotes
  const deleteQuote = async (quoteId: any) => {
    try {
      let response = await deleteQuoteUrl.delete(quoteId, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      deleteAlertClose();
      fetchQuotesByloggedInUser();
    } catch (error) {
      console.log(error);
    }
  };

  // Update qoutes
  const handleSubmitQutoes = (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    editQuote(quote, author);
  };

  const fetchPost = async () => {
    try {
      let response = await quoteUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPosts(response.data);
    } catch (error) {
    }
  };

  //Edit Quotes
  const editQuote = async (quote: string, author: string,) => {
    try {
      let response = await editQuoteUrl.patch('', {
        "quote": quote,
        "author": author,
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setQuote('');
      setAuthor('');
      handleClose();
      fetchQuotesByloggedInUser();
    } catch (error) {
      console.log(error);
    }
  };

  //Update Quotes values
  const updateQuote = async (quoteId: any, quote: string, author: string) => {
    setQuoteId(quoteId);
    setQuote(quote);
    setAuthor(author);
  };
  const fetchQuotesByloggedInUser = async () => {
    try {
      let response = await quoteByloggedInUserUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPosts(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  const fetchLikesQuotesByloggedInUser = async () => {
    try {
      let response = await favouriteQuoteUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setLikesQuotes(response.data);
    } catch (error) {
      console.log(error);
    }
  };
  const fetchDisLikesQuotesByloggedInUser = async () => {
    try {
      let response = await unfavouriteQuoteUrl.get('', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setDisLikesQuotes(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchQuotesByloggedInUser();
    fetchLikesQuotesByloggedInUser();
    fetchDisLikesQuotesByloggedInUser();
  }, []);


  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
      padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));


  const handleClickOpen = () => {
    setOpen(true);

    //handleLike();
  };
  const handleClose = () => {
    setOpen(false);
  };


  const deleteAlertOpen = (quoteId: any) => {
    console.log(quoteId, "deleteAlertOpen")
    setQuoteId(quoteId)
    setDeleteAlertOpen(true);
  };

  const deleteAlertClose = () => {
    setDeleteAlertOpen(false);
  };

  //Update like QuoteID values
  const updateLikeQuoteID = async (quoteId: any,) => {
    setQuoteId(quoteId);
    console.log(quoteId, "quoteIdquoteId")
    //handleLike();
  };

  //Like Quotes API
  const handleLike = async (quoteId: any) => {
    try {
      let response = await likeQuoteUrl.patch(quoteId, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      setPosts(response.data);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <><Grid container sx={{ minWidth: 275, my: 3, display: 'inline-flex' }}>
      <Grid size={12}>
      <Typography
        component="h1"
        variant="h4"
        sx={{ width: '90%', fontSize: 25, my: 2, pl: 1, textAlign: 'left' }}>My Quotes</Typography>
      </Grid>
      <Grid size={12}>
      <Card elevation={3}>
        <Box sx={{ width: '100%', typography: 'body1' }}>
          <TabContext value={value}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <TabList variant="fullWidth" onChange={slectTab} aria-label="tabs">
                <Tab label={<StyledtabBadge badgeContent={posts.length}>
                  Added Quotes
                </StyledtabBadge>} value="1" />
                <Tab label={<StyledtabBadge badgeContent={likesquotes.length}>
                  Liked Quotes
                </StyledtabBadge>} value="2" />
                <Tab label={<StyledtabBadge badgeContent={dislikesquotes.length}>
                  Disliked Quotes
                </StyledtabBadge>} value="3" />
              </TabList>
            </Box>
            <TabPanel value="1">
              {posts.map((post) => {
                return (
                  <>
                    <Box {...defaultProps} sx={{ mx: 12, my: 3, p: 0, }} borderRadius={4} key={post.id}>
                      <Grid container spacing={2}>
                        <Grid size={10} sx={{ p: 3 }}>
                          <Typography variant="subtitle1" align='left'>
                            {post.quote}
                          </Typography>
                        </Grid>
                        <Grid size={2} sx={{ mt: 1 }}>
                          <Stack direction="row" spacing={1}>
                            <IconButton aria-label="delete" onClick={event => { deleteAlertOpen(post.id) }}>
                              <DeleteIcon />
                            </IconButton>
                            <IconButton aria-label="edit" onClick={event => { handleClickOpen(); updateQuote(post.id, post.quote, post.author); }}>
                              <EditIcon />
                            </IconButton>
                          </Stack>
                        </Grid>
                        <Grid size={3}>
                          <ButtonGroup variant="text" sx={{ ml: 2 }}>
                            <Button disabled={(userId == post.user.id)} onClick={event => { handleLike(post.id) }} sx={{ borderRight: '0 !important' }}><ThumbUpIcon sx={{ color: '#057007' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#39be52!important' }}>{post.likes}</Button>
                            <Button disabled={(userId == post.user.id)} onClick={() => setQuoteId(post.id)} sx={{ borderRight: '0 !important' }}><ThumbDownIcon sx={{ color: '#e0610e' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#e29f57 !important' }}>{post.dislikes}</Button>
                          </ButtonGroup>
                        </Grid>
                        <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                        <Grid size={6}>
                          <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                            {post.author}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Box></>
                );
              })}
            </TabPanel>
            <TabPanel value="2">
              {likesquotes.map((post) => {
                return (
                  <>
                    <Box {...defaultProps} sx={{ mx: 12, my: 3, p: 0 }} borderRadius={4} key={post.id}>
                      <Grid container spacing={2}>
                        <Grid size={12} sx={{ p: 3 }}>
                          <Typography variant="subtitle1" align='left'>
                            {post.quote.quote}
                          </Typography>
                        </Grid>
                        <Grid size={3}>
                          <ButtonGroup variant="text" sx={{ ml: 2 }}>
                            <Button disabled={(userId == post.user.id)} onClick={() => setQuoteId(post.id)} sx={{ borderRight: '0 !important' }}><ThumbUpIcon sx={{ color: '#057007' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#39be52!important' }}>{post.quote.likes}</Button>
                            <Button disabled={(userId == post.user.id)} onClick={() => setQuoteId(post.id)} sx={{ borderRight: '0 !important' }}><ThumbDownIcon sx={{ color: '#e0610e' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#e29f57 !important' }}>{post.quote.dislikes}</Button>
                          </ButtonGroup>
                        </Grid>
                        <Grid size={3}>Tag: {post.tags === "" ? null : <Chip label={post.tags} />}</Grid>
                        <Grid size={6}>
                          <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                            {post.quote.author}
                          </Typography>
                        </Grid>

                      </Grid>
                    </Box></>
                );
              })}
            </TabPanel>
            <TabPanel value="3">
              {dislikesquotes.map((post) => {
                return (
                  <>
                    <Box {...defaultProps} sx={{ mx: 12, my: 3, p: 0 }} borderRadius={4} key={post.id}>
                      <Grid container spacing={2}>
                        <Grid size={11} sx={{ p: 3 }}>
                          <Typography variant="subtitle1" align='left'>
                            {post.quote.quote}
                          </Typography>
                        </Grid>
                        <Grid size={2}>
                          <ButtonGroup variant="text" sx={{ ml: 2 }}>
                            <Button onClick={() => setQuoteId(post.id)} sx={{ borderRight: '0 !important' }}><ThumbUpIcon sx={{ color: '#057007' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#39be52!important' }}>{post.quote.likes}</Button>
                            <Button onClick={() => setQuoteId(post.id)} sx={{ borderRight: '0 !important' }}><ThumbDownIcon sx={{ color: '#e0610e' }} /></Button>
                            <Button className='Count' sx={{ backgroundColor: '#e29f57 !important' }}>{post.quote.dislikes}</Button>
                          </ButtonGroup>
                        </Grid>
                        <Grid size={10}>
                          <Typography variant="body2" align='right' sx={{ px: 3, pb: 3 }}>
                            {post.quote.author}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Box></>
                );
              })}
            </TabPanel>
          </TabContext>
        </Box>
      </Card></Grid>
    </Grid>
      <BootstrapDialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
      >
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          Edit Quote
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={(theme) => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent dividers>
          <form onSubmit={handleSubmitQutoes}>
            <TextField
              sx={{ my: 2 }}
              id="outlined-multiline-static"
              label="Quote"
              //multiline
              //rows={4}
              fullWidth
              value={quote}
              onChange={(e) => setQuote(e.target.value)}
            />
            <TextField
              sx={{ my: 2 }}
              id="outlined-textarea"
              label="Author"
              placeholder="Placeholder"
              fullWidth
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
            />
          </form>
        </DialogContent>
        <DialogActions>
          <Button variant="contained" type="submit" startIcon={<SaveIcon />} sx={{ my: 2, backgroundColor: '#509c04' }} onClick={handleSubmitQutoes}>
            Save changes
          </Button>
        </DialogActions>
      </BootstrapDialog>
      <Dialog
        open={delAlertOpen}
        onClose={deleteAlertClose}
      >
        <DialogTitle sx={{ fontSize: 28, width: 300, textAlign: 'center', pb:0 }}>Are you sure ?</DialogTitle>
        <p className='ml25'>you will not be able to recover this record</p>

        <DialogContent>
          <DeleteIcon sx={{ fontSize: 70, width: 300, textAlign: 'center', fill:'#f73030' }} />
        </DialogContent >
        <DialogActions sx={{ paddingRight: 4, mb:3 }} >
          <Button color="secondary" variant="contained" sx={{backgroundColor: '#d32f2f'}} onClick={event => { deleteQuote(quoteId) }}>Yes, Delete it!</Button>
          <Button color="primary" variant="contained" sx={{ backgroundColor: '#898989' }} onClick={deleteAlertClose} autoFocus>No, Keep it!</Button>
        </DialogActions>
      </Dialog>

    </>
  );
}

export default MyQuotes;